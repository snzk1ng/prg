package ejercicio02;

public class Circulo {

	private double radio;

	public Circulo(double radio) {
		
		this.radio = radio;
	}
	
	public double calcularArea() {
		
		double area=0;
		area=Math.PI*Math.pow(radio,2);
		return area;
		
		
	}
	
	public void mostrarArea(double area) {
		
		
		System.out.printf("El area de su circulo es de %.2f cm2 \n", area);
		
	}
	
	
	public double calcularAreaM2(double area) {
		
		double m2;
		double diez=10000.0;
		m2=(double)area/diez;
		return m2;
		
	}
	
	
	public void mostrarAreaM2(double m2) {
		
		System.out.printf("El area en m2 es de %.2f \n ", m2);
		
	}
	
}
