package ejercicio02;

import utilidades.Leer;

public class Principal {

    public static void main(String[] args) {


        double area=0;


        Circulo c1;


        System.out.println("Diga el radio");
        area=Leer.datoDouble();
        c1=new Circulo(area);
        c1.mostrarArea(c1.calcularArea());
        c1.mostrarAreaM2(c1.calcularAreaM2(c1.calcularArea()));





    }

}